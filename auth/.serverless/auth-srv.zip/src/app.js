"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.slsApp = void 0;
var express_1 = __importDefault(require("express"));
require("express-async-errors");
var body_parser_1 = require("body-parser");
var cors_1 = __importDefault(require("cors"));
var cookie_session_1 = __importDefault(require("cookie-session"));
var serverless_http_1 = __importDefault(require("serverless-http"));
var shared_1 = require("@sitechtimes/shared");
var signup_1 = require("./routes/signup");
var signin_1 = require("./routes/signin");
var current_user_1 = require("./routes/current-user");
var signout_1 = require("./routes/signout");
var verify_1 = require("./routes/verify");
// import swaggerUi from 'swagger-ui-express';
// import * as swaggerDocument from '../swagger.json'
var app = express_1.default();
app.set('trust proxy', true);
app.use(body_parser_1.json());
app.use(cors_1.default());
app.use(cookie_session_1.default({
    signed: false,
    secure: false // TODO: has to be true before prod
}));
// app.use('/api/auth/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(signup_1.signupRouter);
app.use(signin_1.signinRouter);
app.use(current_user_1.currentUserRouter);
app.use(signout_1.signoutRouter);
app.use(verify_1.verifyRouter);
app.all('*', function (req, res) {
    throw new shared_1.NotFoundError();
});
app.use(shared_1.errorHandler);
var slsApp = serverless_http_1.default(app);
exports.slsApp = slsApp;
