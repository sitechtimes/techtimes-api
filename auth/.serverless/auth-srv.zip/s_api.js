
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'egonuler',
  applicationName: 'techtimes-api',
  appUid: 'LRrZnMCJnt6ltgR8rX',
  orgUid: 'b22c8136-0ef4-434b-9259-a33eb9f9f2e9',
  deploymentUid: '10bf74a7-c446-4c97-8d95-9913b21dc32e',
  serviceName: 'auth-srv',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'auth-srv-dev-api', timeout: 6 };

try {
  const userHandler = require('./src/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.slsApp, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}