
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'egonuler',
  applicationName: 'techtimes-api',
  appUid: 'LRrZnMCJnt6ltgR8rX',
  orgUid: 'b22c8136-0ef4-434b-9259-a33eb9f9f2e9',
  deploymentUid: 'd73121ec-a2c6-4568-a7b9-0919ff65bdc5',
  serviceName: 'cms-srv',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cms-srv-dev-api', timeout: 6 };

try {
  const userHandler = require('./src/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.slsApp, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}