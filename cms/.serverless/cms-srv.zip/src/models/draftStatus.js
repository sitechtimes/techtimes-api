"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DraftStatus = void 0;
var DraftStatus;
(function (DraftStatus) {
    DraftStatus["Draft"] = "draft";
    DraftStatus["Review"] = "review";
    DraftStatus["Ready"] = "ready";
})(DraftStatus = exports.DraftStatus || (exports.DraftStatus = {}));
