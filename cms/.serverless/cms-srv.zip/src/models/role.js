"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
// TODO: add to shared package
var Role;
(function (Role) {
    Role["Writer"] = "writer";
    Role["Editor"] = "editor";
    Role["Admin"] = "admin";
})(Role = exports.Role || (exports.Role = {}));
