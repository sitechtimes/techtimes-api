"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Category = void 0;
var Category;
(function (Category) {
    Category["COVID"] = "covid";
    Category["Entertainment"] = "entertainment";
    Category["World"] = "world";
    Category["US"] = "us";
    Category["Science"] = "science";
    Category["Technology"] = "technology";
    Category["Sports"] = "sports";
})(Category = exports.Category || (exports.Category = {}));
