"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.slsApp = void 0;
var express_1 = __importDefault(require("express"));
require("express-async-errors");
var body_parser_1 = require("body-parser");
var cookie_session_1 = __importDefault(require("cookie-session"));
var cors_1 = __importDefault(require("cors"));
var serverless_http_1 = __importDefault(require("serverless-http"));
var shared_1 = require("@sitechtimes/shared");
var show_1 = require("./routes/show");
var routes_1 = require("./routes");
var delete_1 = require("./routes/delete");
var update_1 = require("./routes/update");
// import swaggerUi from 'swagger-ui-express';
// import * as swaggerDocument from '../swagger.json'
var app = express_1.default();
app.set('trust proxy', true);
app.use(body_parser_1.json());
app.use(cors_1.default());
app.use(cookie_session_1.default({
    signed: false,
    secure: false, // TODO: has to be true before prod
}));
app.use(shared_1.currentUser);
// app.use('/api/users/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(routes_1.usersRouter);
app.use(show_1.showUserRouter);
app.use(delete_1.deleteUserRouter);
app.use(update_1.updateUserRouter);
app.all('*', function (req, res) {
    throw new shared_1.NotFoundError();
});
app.use(shared_1.errorHandler);
var slsApp = serverless_http_1.default(app);
exports.slsApp = slsApp;
